@extends('layouts.main')

@section('page_title')
    CATEGORIES
@endsection

@section('content')
<categories-table></categories-table>
@endsection