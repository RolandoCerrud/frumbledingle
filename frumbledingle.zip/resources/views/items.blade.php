@extends('layouts.main')

@section('page_title')
    ITEMS
@endsection

@section('content')
<items-table></items-table>
@endsection