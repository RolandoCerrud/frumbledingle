@extends('layouts.main')

@section('page_title')
    Locations
@endsection

@section('content')
<locations-table></locations-table>
@endsection