<?php $__env->startSection('page_title'); ?>
README
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo (new \Parsedown())->text(file_get_contents(base_path() . '/readme.md')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_style'); ?>
<style>
    th,
    td {
        border: 1px solid #999;
        padding: 0.7em;
    }

    th {
        background-color: #121889;
        color: #fff;
    }

    tr:nth-child(even) {
        background-color: #cceeff;
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>